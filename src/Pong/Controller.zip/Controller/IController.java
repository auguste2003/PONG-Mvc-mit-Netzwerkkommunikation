package Pong.Controller;

public interface IController {
    void  nextFrame();

    void userInput(char a);
}
